#include<iostream>
#include<fstream>
#include<string>
#include<vector>
using namespace std;

void openFiles(vector<string>& vec_fileNames)
{
    for(int i = 0; i < vec_fileNames.size(); i++)
   {
        string fileName = vec_fileNames[i];
        string path("D:\\test\\" + fileName + ".txt");

        ofstream inFile;
		inFile.open(path.c_str(),ios::app);

        if(!inFile.is_open())
        {
            cout << "File" << vec_fileNames[i] << "Not Found! 2" << endl;
        }
        else
        {
            cout << "opened file in " << vec_fileNames[i] << endl << endl;
            string line;

                inFile << i;
				inFile.close();
            
            cout << endl;
        }
    }
}
void loadFileNames(vector<string>& vec_fileNames)
{
    ifstream inFile("D:\\test.txt");

    if(!inFile.is_open())
    {
        cout << "File Not Found! 1\n";
        return;
    //  inFile.close(); -- no need to close, it is not open!
    }
    else
    {
        string line;

        while (getline(inFile, line))
        {
            cout << line << endl;
            vec_fileNames.push_back(line);
        }
    }
}
int main()
{
	vector<string> fileNames;
	loadFileNames(fileNames);
	openFiles(fileNames);
	return 0;
}
