
#include"UI.h"
#include"graphics.h"
#include"header.h"

/*void mouseMoveHandler(int x, int y)
{
	printf("Current mouse position: (%d, %d)\n", x, y);
}*/
int main()
{
	
	

	
//waitingScreen();
	InsertScreen();
	searchScreen();
	
	getch();
		/* _select driver and mode that supports multiple background
		colors*/

		/* clean up */
	//test9();
		
	
		closegraph();
	 system("pause");
	  return 0;

  } 

